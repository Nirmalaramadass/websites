// Global SEO Website JavaScript
// Handles RTL/LTR toggle, mobile menu, smooth scrolling, and common functionality

document.addEventListener('DOMContentLoaded', function () {
    injectGlobalThemeStyles();
    applySavedTheme();
    ensureThemeToggleButtons();
    setupThemeToggleHandlers();

    // Initialize RTL/LTR preference
    initializeRTL();

    // Setup desktop navbar dropdowns
    setupNavDropdowns();

    // Setup mobile menu toggle
    setupMobileMenu();


    // Desktop Navbar Dropdowns (Home and Dashboard)
    function setupNavDropdowns() {
        const dropdownButtons = document.querySelectorAll('.nav-dropdown-toggle');

        if (!dropdownButtons.length) return;

        dropdownButtons.forEach((button) => {
            button.addEventListener('click', function (event) {
                event.preventDefault();
                event.stopPropagation();

                const targetId = this.getAttribute('data-dropdown');
                if (!targetId) return;

                const targetMenu = document.getElementById(targetId);
                if (!targetMenu) return;

                const willOpen = targetMenu.classList.contains('hidden');
                closeAllNavDropdowns();

                if (willOpen) {
                    targetMenu.classList.remove('hidden');
                }
            });
        });

        document.addEventListener('click', function (event) {
            const clickedInDropdown = event.target.closest('.nav-dropdown-toggle') || event.target.closest('.nav-dropdown-menu');
            if (!clickedInDropdown) {
                closeAllNavDropdowns();
            }
        });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') {
                closeAllNavDropdowns();
            }
        });
    }

    function closeAllNavDropdowns() {
        document.querySelectorAll('.nav-dropdown-menu').forEach((menu) => {
            menu.classList.add('hidden');
        });
    }
    // Setup smooth scrolling
    setupSmoothScrolling();

    // Setup animations on scroll
    setupScrollAnimations();

    // Setup sticky navbar
    setupStickyNavbar();
});

// Add shared transition and dark-surface styles for consistent theme switching
function injectGlobalThemeStyles() {
    if (document.getElementById('global-theme-style')) return;

    const style = document.createElement('style');
    style.id = 'global-theme-style';
    style.textContent = `
        html {
            color-scheme: light;
        }

        html.dark {
            color-scheme: dark;
        }

        html.theme-switch-ready *,
        html.theme-switch-ready *::before,
        html.theme-switch-ready *::after {
            transition: background-color .3s ease, color .3s ease, border-color .3s ease, box-shadow .3s ease;
        }

        @media (prefers-reduced-motion: reduce) {
            html.theme-switch-ready *,
            html.theme-switch-ready *::before,
            html.theme-switch-ready *::after {
                transition: none !important;
            }
        }

        .theme-toggle-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: .5rem;
            white-space: nowrap;
        }

        .theme-fallback-controls {
            position: fixed;
            top: 1rem;
            right: 1rem;
            z-index: 70;
            display: flex;
            gap: .5rem;
        }

        [dir="rtl"] .theme-fallback-controls {
            right: auto;
            left: 1rem;
        }

        .theme-fallback-controls button {
            padding: .5rem .75rem;
            border-radius: .5rem;
            border: 1px solid rgba(148, 163, 184, 0.35);
            background: rgba(255, 255, 255, 0.92);
            color: #0f172a;
            font-weight: 600;
        }

        html.dark .theme-fallback-controls button {
            background: rgba(15, 23, 42, 0.92);
            border-color: rgba(148, 163, 184, 0.25);
            color: #e2e8f0;
        }

        html.dark .dashboard-shell {
            background: linear-gradient(180deg, #020617 0%, #0f172a 100%) !important;
        }

        html.dark .sidebar,
        html.dark .bg-white,
        html.dark .bg-white\/90 {
            background-color: #0f172a !important;
        }

        html.dark .border-gray-100,
        html.dark .border-gray-200 {
            border-color: #334155 !important;
        }

        html.dark .text-gray-900 {
            color: #f8fafc !important;
        }

        html.dark .text-gray-500 {
            color: #94a3b8 !important;
        }

        html.dark .hover\\:bg-gray-100:hover,
        html.dark .bg-gray-100 {
            background-color: #1e293b !important;
        }
    `;

    document.head.appendChild(style);
}

function ensureThemeToggleButtons() {
    const desktopRTL = document.getElementById('rtl-toggle');
    const mobileRTL = document.getElementById('rtl-toggle-mobile');

    if (desktopRTL && !document.getElementById('dark-toggle')) {
        desktopRTL.insertAdjacentElement('afterend', createThemeToggleButton('dark-toggle', false));
    }

    if (mobileRTL && !document.getElementById('dark-toggle-mobile')) {
        mobileRTL.insertAdjacentElement('afterend', createThemeToggleButton('dark-toggle-mobile', true));
    }

    // Fallback controls for standalone pages that do not have navbar toggles.
    if (!desktopRTL && !mobileRTL && !document.getElementById('theme-fallback-controls')) {
        const controls = document.createElement('div');
        controls.id = 'theme-fallback-controls';
        controls.className = 'theme-fallback-controls';
        controls.innerHTML = `
            <button id="rtl-toggle" type="button" title="Switch direction" aria-label="Toggle RTL/LTR">RTL/LTR</button>
            <button id="dark-toggle" type="button" data-theme-toggle="true" title="Switch theme" aria-label="Toggle dark mode"><i class="fas fa-moon"></i></button>
        `;
        document.body.appendChild(controls);
    }
}

function createThemeToggleButton(id, isMobile) {
    const button = document.createElement('button');
    button.id = id;
    button.type = 'button';
    button.setAttribute('data-theme-toggle', 'true');

    if (isMobile) {
        button.className = 'w-full p-2 rounded-lg glass-card text-center theme-toggle-btn';
        button.innerHTML = '<i class="fas fa-moon"></i>';
    } else {
        button.className = 'p-2 rounded-lg glass-card hover:bg-white/20 transition-all theme-toggle-btn';
        button.innerHTML = '<i class="fas fa-moon text-xl"></i>';
    }

    return button;
}

function applySavedTheme() {
    const savedTheme = localStorage.getItem('theme');
    const preferredTheme = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    const initialTheme = savedTheme === 'dark' || savedTheme === 'light' ? savedTheme : preferredTheme;

    setTheme(initialTheme, false);
    requestAnimationFrame(() => document.documentElement.classList.add('theme-switch-ready'));
}

function setupThemeToggleHandlers() {
    const themeButtons = document.querySelectorAll('[data-theme-toggle="true"], #dark-toggle, #dark-toggle-mobile');

    themeButtons.forEach((button) => {
        if (button.dataset.themeBound === 'true') return;

        button.dataset.themeBound = 'true';
        button.addEventListener('click', function () {
            const isDark = document.documentElement.classList.contains('dark');
            setTheme(isDark ? 'light' : 'dark', true);
        });
    });

    updateThemeButtons(document.documentElement.classList.contains('dark') ? 'dark' : 'light');
}

function setTheme(theme, persist) {
    const darkEnabled = theme === 'dark';
    document.documentElement.classList.toggle('dark', darkEnabled);

    if (persist) {
        localStorage.setItem('theme', theme);
    }

    updateThemeButtons(theme);
    document.dispatchEvent(new CustomEvent('themechange', { detail: { theme } }));
}

function updateThemeButtons(theme) {
    const isDark = theme === 'dark';
    const themeButtons = document.querySelectorAll('[data-theme-toggle="true"], #dark-toggle, #dark-toggle-mobile');

    themeButtons.forEach((button) => {
        const icon = button.querySelector('i');
        if (icon) {
            icon.classList.remove('fa-moon', 'fa-sun');
            icon.classList.add(isDark ? 'fa-sun' : 'fa-moon');
        } else if (button.id === 'dark-toggle' || button.id === 'dark-toggle-mobile') {
            // If the button has no icon yet (fallback), inject one
            button.innerHTML = `<i class="fas ${isDark ? 'fa-sun' : 'fa-moon'}"></i>`;
        }

        const nextTheme = isDark ? 'light' : 'dark';
        button.setAttribute('title', `Switch to ${nextTheme} mode`);
        button.setAttribute('aria-label', `Switch to ${nextTheme} mode`);
    });
}

// Initialize RTL/LTR from localStorage
function initializeRTL() {
    const rtlToggles = document.querySelectorAll('#rtl-toggle, #rtl-toggle-mobile');
    const savedDirection = localStorage.getItem('direction') || 'ltr';

    // Set initial direction
    document.documentElement.setAttribute('dir', savedDirection);
    rtlToggles.forEach((button) => updateRTLButton(button, savedDirection));

    // Add event listeners for all RTL/LTR toggle buttons (desktop + mobile)
    rtlToggles.forEach((button) => {
        button.addEventListener('click', function () {
            const currentDir = document.documentElement.getAttribute('dir');
            const newDir = currentDir === 'ltr' ? 'rtl' : 'ltr';

            document.documentElement.setAttribute('dir', newDir);
            localStorage.setItem('direction', newDir);
            rtlToggles.forEach((toggleBtn) => updateRTLButton(toggleBtn, newDir));

            // Trigger reflow for animations
            triggerReflow();
        });
    });
}

// Update RTL toggle button appearance
function updateRTLButton(button, direction) {
    if (!button) return;

    // Remove icon if it exists and replace with text
    const icon = button.querySelector('i');
    if (icon) {
        icon.remove();
    }

    button.textContent = direction === 'ltr' ? 'RTL' : 'LTR';
    button.className = button.className + ' font-bold tracking-tight text-sm flex items-center justify-center min-w-[44px]';

    // Update button text/tooltip
    button.setAttribute('title', direction === 'ltr' ? 'Switch to RTL' : 'Switch to LTR');
    button.setAttribute('aria-label', `Switch to ${direction === 'ltr' ? 'RTL' : 'LTR'}`);
}

// Particle System Implementation
// Enhanced Particle System Implementation
function initParticles() {
    const canvas = document.getElementById('hero-particles');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    let width, height, particles;
    let mouse = { x: null, y: null, radius: 150 };

    window.addEventListener('mousemove', (e) => {
        const rect = canvas.getBoundingClientRect();
        mouse.x = e.clientX - rect.left;
        mouse.y = e.clientY - rect.top;
    });

    function init() {
        width = canvas.width = canvas.parentElement.offsetWidth;
        height = canvas.height = canvas.parentElement.offsetHeight;
        particles = [];

        // Responsive particle count
        const particleCount = Math.min(Math.floor((width * height) / 15000), 120);

        for (let i = 0; i < particleCount; i++) {
            const size = Math.random() * 2.5 + 1;
            particles.push({
                x: Math.random() * width,
                y: Math.random() * height,
                vx: (Math.random() - 0.5) * 0.8,
                vy: (Math.random() - 0.5) * 0.8,
                size: size,
                baseX: 0,
                baseY: 0,
                density: (Math.random() * 30) + 1
            });
        }
    }

    function draw() {
        ctx.clearRect(0, 0, width, height);

        // Determine primary color based on theme
        const isDark = document.documentElement.classList.contains('dark');
        const particleColor = isDark ? 'rgba(34, 197, 94, 0.5)' : 'rgba(34, 197, 94, 0.4)';
        const lineColor = isDark ? 'rgba(34, 197, 94, 0.08)' : 'rgba(34, 197, 94, 0.05)';

        ctx.fillStyle = particleColor;
        ctx.strokeStyle = lineColor;

        for (let i = 0; i < particles.length; i++) {
            let p = particles[i];

            // Move particles
            p.x += p.vx;
            p.y += p.vy;

            // Bounce off walls
            if (p.x < 0 || p.x > width) p.vx *= -1;
            if (p.y < 0 || p.y > height) p.vy *= -1;

            // Mouse interaction (Repulsion)
            if (mouse.x != null && mouse.y != null) {
                let dx = mouse.x - p.x;
                let dy = mouse.y - p.y;
                let distance = Math.sqrt(dx * dx + dy * dy);

                if (distance < mouse.radius) {
                    const force = (mouse.radius - distance) / mouse.radius;
                    const directionX = dx / distance;
                    const directionY = dy / distance;
                    const moveX = force * directionX * 5;
                    const moveY = force * directionY * 5;

                    p.x -= moveX;
                    p.y -= moveY;
                }
            }

            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();

            // Connect particles
            for (let j = i + 1; j < particles.length; j++) {
                let p2 = particles[j];
                let dx = p.x - p2.x;
                let dy = p.y - p2.y;
                let dist = Math.sqrt(dx * dx + dy * dy);

                if (dist < 150) {
                    let opacity = 1 - (dist / 150);
                    ctx.globalAlpha = opacity * 0.3;
                    ctx.lineWidth = 0.5;
                    ctx.beginPath();
                    ctx.moveTo(p.x, p.y);
                    ctx.lineTo(p2.x, p2.y);
                    ctx.stroke();
                    ctx.globalAlpha = 1;
                }
            }
        }
        requestAnimationFrame(draw);
    }

    window.addEventListener('resize', () => {
        init();
    });

    init();
    draw();
}

// Magnetic Button Interaction
function initMagneticButtons() {
    const buttons = document.querySelectorAll('.btn-magnetic');

    buttons.forEach(btn => {
        btn.addEventListener('mousemove', (e) => {
            const rect = btn.getBoundingClientRect();
            const x = e.clientX - rect.left - rect.width / 2;
            const y = e.clientY - rect.top - rect.height / 2;

            btn.style.transform = `translate(${x * 0.3}px, ${y * 0.3}px)`;
        });

        btn.addEventListener('mouseleave', () => {
            btn.style.transform = 'translate(0px, 0px)';
        });
    });
}

// Trigger reflow for CSS transitions
function triggerReflow() {
    document.body.offsetHeight; // Force reflow
}

// Initialize on load
window.addEventListener('load', () => {
    initParticles();
    initMagneticButtons();
});

// Mobile Menu Toggle
function setupMobileMenu() {
    const menuBtn = document.getElementById('menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');

    if (menuBtn && mobileMenu) {
        menuBtn.addEventListener('click', function () {
            mobileMenu.classList.toggle('hidden');

            // Animate hamburger to X
            const bars = menuBtn.querySelectorAll('.bar');
            if (bars.length === 3) {
                if (!mobileMenu.classList.contains('hidden')) {
                    bars[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
                    bars[1].style.opacity = '0';
                    bars[2].style.transform = 'rotate(-45deg) translate(7px, -6px)';
                } else {
                    bars[0].style.transform = 'none';
                    bars[1].style.opacity = '1';
                    bars[2].style.transform = 'none';
                }
            }
        });
    }

    // Close mobile menu when clicking outside
    document.addEventListener('click', function (event) {
        if (menuBtn && mobileMenu &&
            !menuBtn.contains(event.target) &&
            !mobileMenu.contains(event.target)) {
            mobileMenu.classList.add('hidden');
            const bars = menuBtn.querySelectorAll('.bar');
            if (bars.length === 3) {
                bars[0].style.transform = 'none';
                bars[1].style.opacity = '1';
                bars[2].style.transform = 'none';
            }
        }
    });
}

// Smooth Scrolling for Anchor Links
function setupSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            if (href !== '#' && href.length > 1) {
                const target = document.querySelector(href);
                if (target) {
                    e.preventDefault();
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });
}

// Scroll Animations using Intersection Observer
function setupScrollAnimations() {
    const observerOptions = {
        threshold: 0.15,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const delay = entry.target.getAttribute('data-delay') || '0ms';
                entry.target.style.transitionDelay = delay;
                entry.target.classList.add('animate-active');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Observe elements with animation classes
    document.querySelectorAll('.animate-on-scroll').forEach((el, index) => {
        el.classList.add('reveal-init');
        // Auto-stagger if no delay is provided
        if (!el.getAttribute('data-delay')) {
            const rowItemIndex = index % 3; // Assume 3 columns for auto-stagger
            el.setAttribute('data-delay', `${rowItemIndex * 150}ms`);
        }
        observer.observe(el);
    });
}

// Counter Animation for Stats
function animateCounter(element, target, duration = 2000) {
    const start = 0;
    const increment = target / (duration / 16); // 60 FPS
    let current = start;

    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = target.toLocaleString();
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current).toLocaleString();
        }
    }, 16);
}

// Initialize counters when they come into view
function initCounters() {
    const counterObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const counter = entry.target;
                const target = parseInt(counter.getAttribute('data-target'));
                animateCounter(counter, target);
                counterObserver.unobserve(counter);
            }
        });
    }, { threshold: 0.5 });

    document.querySelectorAll('[data-counter]').forEach(counter => {
        counterObserver.observe(counter);
    });
}

// Form Validation Helper
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return false;

    const inputs = form.querySelectorAll('input[required], textarea[required]');
    let isValid = true;

    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.classList.add('border-red-500');
            isValid = false;
        } else {
            input.classList.remove('border-red-500');

            // Email validation
            if (input.type === 'email') {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(input.value)) {
                    input.classList.add('border-red-500');
                    isValid = false;
                }
            }
        }
    });

    return isValid;
}

// Password Visibility Toggle
function togglePassword(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon = document.getElementById(iconId);

    if (input && icon) {
        if (input.type === 'password') {
            input.type = 'text';
            icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858-5.908a9.026 9.026 0 035.422 0m4.514-4.514a10 10 0 010 14.142M15.528 8.472a10 10 0 010 14.142" />';
        } else {
            input.type = 'password';
            icon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />';
        }
    }
}

// Sticky Navbar Effect
function setupStickyNavbar() {
    const navbar = document.getElementById('navbar');
    if (!navbar) return;

    window.addEventListener('scroll', () => {
        if (window.scrollY > 20) {
            navbar.classList.add('scrolled', 'shadow-lg');
        } else {
            navbar.classList.remove('scrolled', 'shadow-lg');
        }
    });
}

// Add custom CSS for animations
const style = document.createElement('style');
style.textContent = `
    .reveal-init {
        opacity: 0;
        transform: translateY(40px);
        transition: all 0.8s cubic-bezier(0.22, 1, 0.36, 1);
    }
    
    .animate-active {
        opacity: 1;
        transform: translateY(0);
    }
    
    .hover-lift {
        transition: transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.4s ease;
    }
    
    .hover-lift:hover {
        transform: translateY(-15px) scale(1.03) rotateX(2deg) rotateY(2deg);
        box-shadow: 0 30px 60px rgba(0, 0, 0, 0.15);
        z-index: 10;
    }
    
    .btn-magnetic {
        transition: transform 0.3s cubic-bezier(0.23, 1, 0.32, 1);
        display: inline-block;
    }
    
    .glass-modern {
        background: rgba(255, 255, 255, 0.03);
        backdrop-filter: blur(12px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.2);
    }
    
    .dark .glass-modern {
        background: rgba(15, 23, 42, 0.6);
        border: 1px solid rgba(255, 255, 255, 0.05);
    }

    #hero-particles {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 1;
    }

    @keyframes shine {
        0% { left: -100%; }
        100% { left: 100%; }
    }

    .card-shine {
        position: relative;
        overflow: hidden;
    }

    .card-shine::after {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 50%;
        height: 100%;
        background: linear-gradient(
            to right,
            transparent,
            rgba(255, 255, 255, 0.1),
            transparent
        );
        transform: skewX(-25deg);
        transition: 0.75s;
    }

    .card-shine:hover::after {
        animation: shine 1.5s forwards;
    }

    /* Direction-aware animations */
    [dir="rtl"] .reveal-init {
        transform: translateY(40px);
    }
`;
document.head.appendChild(style);
